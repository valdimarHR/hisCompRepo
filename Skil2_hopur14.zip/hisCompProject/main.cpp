#include <QCoreApplication>
#include <iostream>
#include <QtSql>
#include "UI/ui.h"

using namespace std;

int main()
{
    ui appUI;
    return appUI.start();

}
