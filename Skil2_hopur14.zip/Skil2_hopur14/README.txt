HisComp stands for History of Computers Science.

GitHub repository: https://github.com/valdimarHR/hisCompRepo
Qt project files in: "hisCompProject" folder
Executable program in: "executableProgram" folder