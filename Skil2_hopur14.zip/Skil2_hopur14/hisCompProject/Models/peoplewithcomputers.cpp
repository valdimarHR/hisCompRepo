#include "peoplewithcomputers.h"

peopleWithComputers::peopleWithComputers()
{

}
