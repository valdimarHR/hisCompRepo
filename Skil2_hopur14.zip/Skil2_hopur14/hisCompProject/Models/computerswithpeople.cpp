#include "computerswithpeople.h"

computersWithPeople::computersWithPeople()
{

}

